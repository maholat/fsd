import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Dijkstra {

	private class Item implements Comparable {
		// Used for PriorityQueue
		private int distance;
		private int node;
		private int last;

		private Item(int d, int x, int y) {
			distance = d;
			node = x;
			last = y;
		}

		public int compareTo(Object z) {
			return distance - ((Item) z).distance;
		}
	}

	private class Vertex {
		private EdgeNode edges1;
		private EdgeNode edges2;

		private Vertex() {
			edges1 = null;
			edges2 = null;
		}

		private void addEdge1(EdgeNode node) {
			node.next1 = edges1;
			edges1 = node;
		}

		private void addEdge2(EdgeNode node) {
			node.next2 = edges2;
			edges2 = node;
		}
		public String toString() {
			return edges1+ "            " +edges2;
		}

	}

	private class EdgeNode {
		private int vertex1;
		private int vertex2;
		private EdgeNode next1;
		private EdgeNode next2;
		private int weight;

		private EdgeNode(int v1, int v2, EdgeNode e1, EdgeNode e2, int w) {
			// PRE: v1 < v2
			vertex1 = v1;
			vertex2 = v2;
			next1 = e1;
			next2 = e2;
			weight = w;
		}
		public String toString() {
			return "v1 "+vertex1+" v2 "+vertex2+ " w "+weight+"               next1"+next1+"       next2"+next2;
		}
	}

	private Vertex[] g;
	int numNodes;
	Item[] endgame;

	public Dijkstra(int size) {
		g = new Vertex[size];
		for (int i = 0; i < g.length; i++) {
			g[i] = new Vertex();
		}
	}

	public void addEdge(int v1, int v2, int w) {
		// PRE: v1 and v2 are legitimate vertices
		// (i.e. 0 <= v1 < g.length and 0 <= v2 < g.length
		// System.out.println(v1+" "+v2+" "+w);
		g[v1].addEdge1(new EdgeNode(v1, v2, null, null, w));
		// System.out.println(v1+" "+v2+" "+w);
		g[v2].addEdge2(g[v1].edges1);
		// System.out.println(v1+" "+v2+" "+w);
	}

	public void printRoutes(int j) {
		// find and print the best routes from j to all other nodes in the graph
		endgame = new Item[g.length];
		for (int i = 0; i < endgame.length; i++) {
			endgame[i] = new Item(2000000000, i, -1);
		}
		PriorityQueue<Item> p = new PriorityQueue<>();
		endgame[j].distance = 0;
		p.add(endgame[j]);
		routes(p);
//		for (int i = 0; i < endgame.length; i++) {
//			System.out.println(
//					"distance: " + endgame[i].distance + " last " + endgame[i].last + " node: " + endgame[i].node);
//		}
		for (int i = 0; i < endgame.length; i++) {
			int dis = endgame[i].distance;
			Item check = endgame[i];
			String str = check.node + " ";
			while (check.last != -1) {
				//System.out.println("farwell");
				str = str + check.last + " ";
				check = endgame[check.last];
			}
			System.out.println(str + " distance:" + dis);

		}

		// Note discussion in class of the limitation of Java�s Priority
		// Queue for this algorithm
	}

	private void routes(PriorityQueue<Item> pro) {
		if (pro.isEmpty()) {
			return;
		}
		Item base = pro.remove();
		while (base.distance > endgame[base.node].distance) {
			//System.out.println("yo");
			if (pro.isEmpty()) {
				return;
			}
			base = pro.remove();
		}
		EdgeNode head1 = g[base.node].edges1;
		EdgeNode head2 = g[base.node].edges2;
		while (head1 != null) {
			// System.out.println("hi");
			Item toAdd = endgame[head1.vertex2];
			if (toAdd.distance >= (head1.weight + base.distance)) {

				toAdd.last = head1.vertex1;
				toAdd.distance = head1.weight + base.distance;
				endgame[head1.vertex2] = toAdd;
				pro.add(toAdd);
			}
			head1 = head1.next1;
		}
		while (head2 != null) {
			// System.out.println("bye");
			Item toAdd = endgame[head2.vertex1];
			if (toAdd.distance >= (head2.weight + base.distance)) {
				toAdd.last = head2.vertex2;
				toAdd.distance = head2.weight + base.distance;
				endgame[head2.vertex1] = toAdd;
				pro.add(toAdd);
			}
			head2 = head2.next2;
		}
		routes(pro);
	}

	public static void main(String args[]) throws IOException {
		BufferedReader b = new BufferedReader(new FileReader(args[0]));
		String line = b.readLine();
		int numNodes = new Integer(line);
		line = b.readLine();
		int source = new Integer(line);
		System.out.println(source);
		Dijkstra g = new Dijkstra(numNodes);
		line = b.readLine();
		while (line != null) {
			Scanner scan = new Scanner(line);
			g.addEdge(scan.nextInt(), scan.nextInt(), scan.nextInt());
			line = b.readLine();
		}
		g.printRoutes(source);
//		 for(int i=0;i<numNodes;i++) {
//		 System.out.println(g.g[i]);
//		 }
	}
}