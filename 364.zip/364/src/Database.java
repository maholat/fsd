
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

	Connection c = null;
	Statement stmt = null;
	
	Database(){
		//try to connect to database
		try {
			//gives access to the JDBC jar file
			//file directory to the SQLite file. Make sure this is correct!
			c = DriverManager.getConnection("jdbc:sqlite:C:/Users/mahol/Desktop/CS364.db");
			System.out.println("Successful connection to database.");
		}catch(Exception e){
			System.out.println(e);
		}
	}
	public ResultSet runQuery(String query){
		PreparedStatement stmt;
		ResultSet results= null;
		try {
			stmt = c.prepareStatement(query);
			results = stmt.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return results;
	}
}
	