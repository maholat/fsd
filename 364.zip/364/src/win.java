
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class win {
	static Database d;
	JFrame window;
	JLabel inLabel;
	JTextField dis;
	@SuppressWarnings("rawtypes")
	JComboBox input;
	public static void main(String[] args) {
		win coder = new win();
		d= new Database();
		coder.makeWindow();

	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void makeWindow() {
		int winLength = 900;
		int winHeight = 900;
		window = new JFrame();
		window.setSize(winLength, winHeight);
		window.setVisible(true);
		window.getContentPane().setBackground(java.awt.Color.LIGHT_GRAY);
		window.setLayout(null);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setTitle("Lucrative Library");
		int graphicHeight = 25;
		int x1 = 20;
		int x2 = 75;
		int y1 = winHeight / 5;
		inLabel = new JLabel("Wanted Query:");
		inLabel.setBounds(x1, 10, 200, graphicHeight);
		window.add(inLabel);
        int x = 10;
        int y = ( winHeight - 5 * graphicHeight ) / 2;
        String[] inner= {"Number of Books","Alphbetacal authors","Alphbetacal location","Book ids","Most books","highest member id"};
        int graphicWidth = window.getWidth() - (x+80);
		input = new JComboBox(inner);
        input.setBounds( x, 30, graphicWidth, 30 );
        window.add( input );
        EventButton but= new EventButton(this);
        but.setBounds(5+(graphicWidth+x), 30, 60, 30);
        but.setText("GO");
        window.add( but );
        dis = new JTextField();
        dis.setBounds(x, 70, window.getWidth()-(x*2), 600);
        window.add(dis);
        window.repaint();
	}

	 public void buttonPressed() {
	       String x= input.getSelectedItem().toString();
	       if(x=="Number of Books") {
	    	   
				dis.setText(d.runQuery("SELECT Author.LastName, count(*) FROM Book NATURAL JOIN Author GROUP BY Author.LastName").toString());
		
	       }
	       else if(x=="Alphbetacal authors") {
	    	   dis.setText(d.runQuery("SELECT Author.LastName, Book.Title\r\n" + 
	    	   		"FROM Author NATURAL JOIN Book\r\n" + 
	    	   		"GROUP BY Author.LastName\r\n" + 
	    	   		"ORDER BY Author.LastName ASC\r\n" + 
	    	   		"LIMIT 10").toString());
	       }
	       else if(x=="Alphbetacal location"){
	    	   dis.setText(d.runQuery("SELECT LocationName\r\n" + 
	    	   		"FROM Location\r\n" + 
	    	   		"ORDER BY LocationName\r\n" + 
	    	   		"LIMIT 2\r\n" + 
	    	   		"OFFSET 3").toString());
	       }
	      else if(x== "Book ids"){
	    	  d.runQuery("SELECT Book.Title\r\n" + 
	    	  		"FROM Book\r\n" + 
	    	  		"GROUP BY BookID\r\n" + 
	    	  		"HAVING BookID >= 10 AND BookID <= 15");
	      }
	      else if(x== "Most books"){
	    	  dis.setText(d.runQuery("SELECT Book.Title\r\n" + 
	    	  		"FROM Book NATURAL JOIN Author\r\n" + 
	    	  		"WHERE Author.LastName = (SELECT Author.LastName\r\n" + 
	    	  		"FROM Author Natural Join Book\r\n" + 
	    	  		"GROUP BY Author.LastName\r\n" + 
	    	  		"ORDER BY count(*) DESC\r\n" + 
	    	  		"LIMIT 1)").toString());				   
	     }
	     else if(x=="highest member id"){
	    	 dis.setText(d.runQuery("SELECT Book.Title, MemberID, Member.FirstName, Member.LastName\r\n" + 
	    	 		"FROM Member NATURAL JOIN Book\r\n" + 
	    	 		"WHERE MemberID = (SELECT MemberID\r\n" + 
	    	 		"FROM Member\r\n" + 
	    	 		"ORDER BY MemberID DESC\r\n" + 
	    	 		"LIMIT 1)").toString());
	     }
	        
	    }

}
